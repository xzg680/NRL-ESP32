import{w as e,y as t,a as o,_ as i,t as l,i as n,x as a}from"./styles-sT2V1cOw.js";
const s=e`
  <svg
    version="1.1"
    id="Capa_1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 510.322 510.322"
    xml:space="preserve"
    style="width: 28px; vertical-align: middle;"
  >
    <g>
      <path
        style="fill:currentColor;"
        d="M429.064,159.505c0-0.151,0.086-1.057,0.086-1.057c0-75.282-61.261-136.521-136.543-136.521    c-52.244,0-97.867,30.587-120.753,76.339c-11.67-9.081-25.108-15.682-40.273-15.682c-37.166,0-67.387,30.199-67.387,67.387    c0,0,0.453,3.279,0.798,5.824C27.05,168.716,0,203.423,0,244.516c0,25.389,9.901,49.268,27.848,67.171    c17.968,17.99,41.804,27.869,67.193,27.869h130.244v46.83h-54.66l97.694,102.008l95.602-102.008h-54.66v-46.83H419.25    c50.174,0,91.072-40.855,91.072-90.986C510.3,201.827,474.428,164.639,429.064,159.505z M419.207,312.744H309.26v-55.545h-83.975    v55.545H95.019c-18.184,0-35.333-7.075-48.211-19.996c-12.878-12.878-19.953-30.005-19.953-48.189    c0-32.68,23.21-60.808,55.264-66.956l12.511-2.394l-2.092-14.431l-1.488-10.785c0-22.347,18.184-40.51,40.531-40.51    c13.266,0,25.691,6.514,33.305,17.408l15.229,21.873l8.52-25.303c15.013-44.652,56.796-74.656,103.906-74.656    c60.506,0,109.709,49.203,109.709,109.644l-1.337,25.712l15.121,0.302l3.149-0.086c35.419,0,64.216,28.797,64.216,64.216    C483.401,283.969,454.604,312.744,419.207,312.744z"
      />
    </g>
  </svg>
`;
const d=()=>{try{return localStorage.getItem("nrl_lang")==="zh"?"zh":"en"}catch(e){return"en"}},r=(e,t)=>d()==="zh"?t:e;
let c=class extends n{render(){const e=(()=>{var e,t;const o=window.navigator.userAgent,i=(null===(t=null===(e=window.navigator)||void 0===e?void 0:e.userAgentData)||void 0===t?void 0:t.platform)||window.navigator.platform;return-1!==["macOS","Macintosh","MacIntel","MacPPC","Mac68K"].indexOf(i)?"Mac OS":-1!==["iPhone","iPad","iPod"].indexOf(i)?"iOS":-1!==["Win32","Win64","Windows","WinCE"].indexOf(i)?"Windows":/Android/.test(o)?"Android":/Linux/.test(i)?"Linux":null})();return a`
      <ew-dialog open @closed=${this._handleClose}>
        <div slot="headline">${r("No port selected","未选择串口")}</div>
        <div slot="content">
          <div>
            ${r("If you didn't select a port because you didn't see your device listed, try the following steps:","如果没有看到设备串口，请按下面步骤检查：")}
          </div>
          <ol>
            <li>${r("Make sure that the device is connected to this computer.","确认设备已经连接到当前电脑。")}</li>
            <li>${r("Make sure the device is powered on.","确认设备已经上电。")}</li>
            <li>${r("Make sure that the USB cable can be used for data and is not a power-only cable.","确认 USB 线支持数据传输，不是只能充电的线。")}</li>
            ${"Linux"===e?a`
                  <li>
                    ${r("If you are using Linux, make sure that your user is part of the dialout group so it has permission to access the device.","如果使用 Linux，请确认当前用户已加入 dialout 组，有权限访问串口。")}
                    <code class="block">sudo usermod -a -G dialout YourUserName</code>
                  </li>
                `:""}
            <li>
              ${r("Make sure you have the right drivers installed. Below are the drivers for common chips used in ESP devices:","确认已安装正确驱动。下面是常见 ESP 设备串口芯片驱动：")}
              <ul>
                <li>
                  CP2102 ${r("driver","驱动")}:
                  <a href="https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers" target="_blank" rel="noopener">Windows & Mac</a>
                </li>
                <li>
                  CH342/CH343/CH9102 ${r("driver","驱动")}:
                  <a href="https://www.wch.cn/downloads/CH343SER_ZIP.html" target="_blank" rel="noopener">Windows</a>,
                  <a href="https://www.wch.cn/downloads/CH34XSER_MAC_ZIP.html" target="_blank" rel="noopener">Mac</a>
                  <br />
                  ${r("download via the blue button with the","通过带有")} ${s} ${r("icon","图标的蓝色按钮下载")}
                </li>
                <li>
                  CH340/CH341 ${r("driver","驱动")}:
                  <a href="https://www.wch.cn/downloads/CH341SER_ZIP.html" target="_blank" rel="noopener">Windows</a>,
                  <a href="https://www.wch.cn/downloads/CH341SER_MAC_ZIP.html" target="_blank" rel="noopener">Mac</a>
                  <br />
                  ${r("download via the blue button with the","通过带有")} ${s} ${r("icon","图标的蓝色按钮下载")}
                </li>
              </ul>
            </li>
          </ol>
        </div>
        <div slot="actions">
          ${this.doTryAgain?a`
                <ew-text-button @click=${this.close}>${r("Cancel","取消")}</ew-text-button>
                <ew-text-button @click=${this.tryAgain}>${r("Try again","重试")}</ew-text-button>
              `:a`
                <ew-text-button @click=${this.close}>${r("Close","关闭")}</ew-text-button>
              `}
        </div>
      </ew-dialog>
    `}tryAgain(){var e;this.close(),null===(e=this.doTryAgain)||void 0===e||e.call(this)}close(){this.shadowRoot.querySelector("ew-dialog").close()}async _handleClose(){this.parentNode.removeChild(this)}};c.styles=[t,o`
      li + li,
      li > ul {
        margin-top: 8px;
      }
      ul,
      ol {
        margin-bottom: 0;
        padding-left: 1.5em;
      }
      li code.block {
        display: block;
        margin: 0.5em 0;
      }
    `],c=i([l("ewt-no-port-picked-dialog")],c);const p=async e=>{const t=document.createElement("ewt-no-port-picked-dialog");return t.doTryAgain=e,document.body.append(t),!0};export{p as openNoPortPickedDialog};
